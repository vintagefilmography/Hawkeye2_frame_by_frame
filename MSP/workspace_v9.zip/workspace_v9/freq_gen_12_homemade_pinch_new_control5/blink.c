/* --COPYRIGHT--,BSD_EX
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *******************************************************************************
 *
 *                       MSP430 CODE EXAMPLE DISCLAIMER
 *
 * MSP430 code examples are self-contained low-level programs that typically
 * demonstrate a single peripheral function or device feature in a highly
 * concise manner. For this the code may rely on the device's power-on default
 * register values and settings such as the clock configuration and care must
 * be taken when combining code from several examples to avoid potential side
 * effects. Also see www.ti.com/grace for a GUI- and www.ti.com/msp430ware
 * for an API functional library-approach to peripheral configuration.
 *
 * --/COPYRIGHT--*/
//******************************************************************************
//  MSP430G2xx1 Demo - Timer_A, Toggle P1.0, CCR0 Cont. Mode ISR, DCO SMCLK
//
//  Description: Toggle P1.0 using software and TA_0 ISR. Toggles every
//  50000 SMCLK cycles. SMCLK provides clock source for TACLK.
//  During the TA_0 ISR, P1.0 is toggled and 50000 clock cycles are added to
//  CCR0. TA_0 ISR is triggered every 50000 cycles. CPU is normally off and
//  used only during TA_ISR.
//  ACLK = n/a, MCLK = SMCLK = TACLK = default DCO
//
//           MSP430G2xx1
//         ---------------
//     /|\|            XIN|-
//      | |               |
//      --|RST        XOUT|-
//        |               |
//        |           P1.0|-->LED
//
//  D. Dang
//  Texas Instruments Inc.
//  October 2010
//  Built with CCS Version 4.2.0 and IAR Embedded Workbench Version: 5.10
//******************************************************************************

#include <msp430.h>
unsigned int volatile counter = 0;   // main counter
unsigned int volatile enable_cap;  // enable capstan in slow mode
unsigned int volatile toggle = 1;
unsigned int volatile frame_count = 0;
unsigned int volatile frame_count_toggle = 0;
unsigned int volatile edge_detect = 0;
unsigned int volatile flash = 0;
unsigned int volatile up_bounce = 0;
unsigned int volatile down_bounce = 0;
unsigned int volatile step_delay = 0x16C4;
unsigned int volatile write_flash_latch = 0;
unsigned int volatile up_button = 0;
unsigned int volatile down_button = 0;
unsigned int volatile up_latch = 0;
unsigned int volatile down_latch = 0;
unsigned int volatile up_latch_count = 0;
unsigned int volatile down_latch_count = 0;
unsigned int volatile film_format = 1;
unsigned int P1IN_BIT7_t = 1;
unsigned int P1IN_BIT5_t = 1;
unsigned int P1IN_BIT2_t = 1;
unsigned int P1IN_BIT4_t = 1;
unsigned int P1IN_BIT6_t = 1;   //REW debug
unsigned int P2IN_BIT6_t = 1;   //S8-R8 switch debug




char  value;                                // 8-bit value to write to segment A

// Function prototypes
void write_SegC (char value, int add, int erase);
void copy_C2D (void);
void flash_write(int delay);



int main(void)
{
//char *Flash_ptrD = (char *) 0x1000;
  char read_value = 0;
  int add = 0x1000;
  char *Flash_ptrD;                          // Flash pointer
  Flash_ptrD = (char *) add;              // Initialize Flash pointer
  int write_value = 1234;

  WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT
  P1DIR |= 0x0b;                            // P1.0 P1.1 P1.8 output
  P2DIR &= ~BIT6;
  P2DIR |= BIT7;
  P1SEL = 0;
  P2SEL = 0;
  CCTL0 = CCIE;                             // CCR0 interrupt enabled
  CCR0 = 50000;
  TACTL = TASSEL_2 + MC_2;                  // SMCLK, contmode
  P1OUT = P1OUT & 0xFD;                     // Turn off TKM
  P1OUT = P1OUT & 0xEF;                     // Turn capstan motor off
  P1OUT = P1OUT | 0x08;                     // Turn stepper on
  P1REN = 0;

  // Set clock to 4MHz
  BCSCTL1 &= ~(BIT2);                 // set to DCO(11,3)
  BCSCTL1 |= (BIT3 + BIT1 + BIT0);
  DCOCTL &= ~BIT7;
  DCOCTL |= BIT5 + BIT6;

  P1OUT = P1OUT | 0x08;               // Turn stepper on
  P1OUT = P1OUT | 0x02;               // Turn takeup on                       // Clear Lock bit
  P2OUT = P2OUT & 0x7F;               // Turn cam trigger off

  // Check film format
  if (P1IN & BIT6)     //If rewind off then formats 1 and 2
  //if (P1IN_BIT6_t)
  {
      if(P2IN & BIT6)  // S8-R8 switch check
      //if(P2IN_BIT6_t)
      {
          film_format = 1;
          add = 0x1000;
      }
      else
      {
          film_format = 2;
          add = 0x1002;
      }
  }
  else                 // Rewind on for fromats 3 and 4
  {
      if(P2IN & BIT6)
      //if(P2IN_BIT6_t)
      {
          film_format = 3;
          add = 0x1004;
      }
      else
      {
          film_format = 4;
          add = 0x1006;
      }
  }
  Flash_ptrD = (char *) add;
  // Test wrire flash value
  //flash_write(write_value);

  // Read delay from flash

  read_value = *Flash_ptrD++;
  step_delay = (int) (read_value << 8);

  read_value = *Flash_ptrD++;
  step_delay = step_delay + (int)read_value;
  up_button = 0;
  down_button = 0;

  __bis_SR_register(LPM0_bits + GIE);       // Enter LPM0 w/ interrupt

}

void flash_write(int delay)
{
    char value = 0;
    int  add = 0x1000;
    int erase = 0;
    char *Flash_ptr;                          // Flash pointer
    int delay1 = 0;
    int delay2 = 0;
    int delay3 = 0;
    int delay4 = 0;


    Flash_ptr = (char *) add;              // Initialize Flash pointer

    //Read all film formats stored here
     value = *Flash_ptr++;
     delay1 = (int) (value << 8);
     value = *Flash_ptr++;
     delay1 = delay1 + (int)value;

     value = *Flash_ptr++;
     delay2 = (int) (value << 8);
     value = *Flash_ptr++;
     delay2 = delay2 + (int)value;

     value = *Flash_ptr++;
     delay3 = (int) (value << 8);
     value = *Flash_ptr++;
     delay3 = delay3 + (int)value;

     value = *Flash_ptr++;
     delay4 = (int) (value << 8);
     value = *Flash_ptr++;
     delay4 = delay4 + (int)value;

     //Update delay from the latest value
     if(film_format == 1)
     {
         add = 0x1000;
         delay1 = delay;
     }
     if(film_format == 2)
     {
         add = 0x1002;
         delay2 = delay;
     }
     if(film_format == 3)
     {
         add = 0x1004;
         delay3 = delay;
     }
     if(film_format == 4)
     {
         add = 0x1006;
         delay4 = delay;
     }

    // Write values back into flash
    WDTCTL = WDTPW + WDTHOLD;                 // Stop watchdog timer
    if (CALBC1_1MHZ==0xFF)                    // If calibration constant erased
    {
        while(1);                               // do not load, trap CPU!!
    }
    DCOCTL = 0;                               // Select lowest DCOx and MODx settings
    BCSCTL1 = CALBC1_1MHZ;                    // Set DCO to 1MHz
    DCOCTL = CALDCO_1MHZ;
    FCTL2 = FWKEY + FSSEL0 + FN1;             // MCLK/3 for Flash Timing Generator

    add = 0x1000;
    value = (char) (delay1 >> 8);              // initialize value most sig 8 bits first
    erase  = 1;
    write_SegC(value,add,erase);             // Write segment C, increment value
    value = (char)delay1;                     // initialize value least sig 8 bits
    add = add + 1;
    erase = 0;
    write_SegC(value,add,erase);             // Write segment C, increment value

    add++;
    value = (char) (delay2 >> 8);              // initialize value most sig 8 bits first
    write_SegC(value,add,erase);             // Write segment C, increment value
    value = (char)delay2;                     // initialize value least sig 8 bits
    add = add + 1;
    write_SegC(value,add,erase);             // Write segment C, increment value

    add++;
    value = (char) (delay3 >> 8);              // initialize value most sig 8 bits first
    write_SegC(value,add,erase);             // Write segment C, increment value
    value = (char)delay3;                     // initialize value least sig 8 bits
    add = add + 1;
    write_SegC(value,add,erase);             // Write segment C, increment value

    add++;
    value = (char) (delay4 >> 8);              // initialize value most sig 8 bits first
    write_SegC(value,add,erase);             // Write segment C, increment value
    value = (char)delay4;                     // initialize value least sig 8 bits
    add = add + 1;
    write_SegC(value,add,erase);             // Write segment C, increment value
}

void write_SegC (char value, int add, int erase)
{
  char *Flash_ptr;                          // Flash pointer

  Flash_ptr = (char *) add;              // Initialize Flash pointer
  FCTL1 = FWKEY + ERASE;                    // Set Erase bit
  FCTL3 = FWKEY;                            // Clear Lock bit
  if(erase == 1)
      {
      *Flash_ptr = 0;                           // Dummy write to erase Flash segment
      }
  FCTL1 = FWKEY + WRT;                      // Set WRT bit for write operation

  *Flash_ptr++ = value;                   // Write value to flash


  FCTL1 = FWKEY;                            // Clear WRT bit
  FCTL3 = FWKEY + LOCK;                     // Set LOCK bit
}


// Timer A0 interrupt service routine
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=TIMERA0_VECTOR
__interrupt void Timer_A (void)
#elif defined(__GNUC__)
void __attribute__ ((interrupt(TIMERA0_VECTOR))) Timer_A (void)
#else
#error Compiler not supported!
#endif
{

        CCR0 += 500;      // 1 FPS

        //P1OUT = P1OUT | 0x08;     // Stepper on
        P1OUT = P1OUT & 0xf7;

        if(counter <= step_delay)
        {
            counter++;
            P1OUT ^= 0x01;    //Toggle step clock
        }
        else if((counter > step_delay)&&(counter < (step_delay + 1000*4)))
        {
            counter++;        // Pause for camera
        }
        else
        {
            counter = 0;
        }
        if(counter > step_delay + 200)
        {
            P2OUT = P2OUT | 0x80;     // Trigger on
        }
        if(counter > step_delay + 300)           // was 6250
        {
            P2OUT = P2OUT & 0x7F;      // Turn cam trigger off
        }
        if(counter == 100)
          {
              P1OUT = P1OUT | 0x02;    // Turn takeup on
          }
        if(counter == 4000)
        {
            P1OUT = P1OUT & 0xFD;      // Turn takeup off
        }


        // TUNE MODE
        if(!(P1IN & BIT7) && !(P1IN & BIT5))       // Tune mode on
        //if(!(P1IN_BIT7_t) && !(P1IN_BIT5_t))       // Tune mode on debug - run and alg

        {
            write_flash_latch = 1;
            if(!(P1IN & BIT2))    // Tune Up button debounce
            //if(!(P1IN_BIT2_t))    // Tune Up button debounce debug
            {

                if (up_button == 0)
                {
                    up_bounce++;
                }
                if (up_bounce > 100)
                {
                    up_button = 1;
                }
            }
            else
            {
                up_bounce = 0;
                up_button = 0;
                up_latch = 0;
            }

            if(!(P1IN & BIT4))    // Tune Down Button debounce
            //if(!(P1IN_BIT4_t))    // Tune Down Button debounce debug
            {
                if (down_button == 0)
                {
                    down_bounce++;
                }
                if (down_bounce > 100)
                {
                    down_button = 1;
                }
            }
             else
             {
                down_bounce = 0;
                down_button = 0;
                down_latch = 0;
             }

             if((up_button == 1)&&(up_latch == 0)&&(down_button == 0)) // Up increment
             {
                up_latch = 1;
                step_delay--;
             }
             if((up_button == 1)&&(up_latch == 1)&&(down_button == 1))
             {
                 up_latch_count++;
                 if(up_latch_count > 100)
                 {
                     up_latch_count = 0;
                     step_delay--;
                 }
             }

             if((down_button == 1)&&(down_latch == 0)&&(up_button == 0)) // Down decrement
              {
                 down_latch = 1;
                 step_delay++;
              }
              if((down_button == 1)&&(down_latch == 1)&&(up_button == 1))
              {
                  down_latch_count++;
                  if(down_latch_count > 100)
                  {
                      step_delay++;
                      down_latch_count = 0;
                  }
              }
          }
          else
          {
             if(write_flash_latch == 1)
             {
                 write_flash_latch = 0;
                 flash_write(step_delay);
             }

          }


        // RUN SWITCH CHECK

        if(!(P1IN & BIT7))       // On Off control
         {
            P1OUT = P1OUT & 0xf7;     //ON
         }
        else
         {
            if(!(P1IN & BIT5))    // If slow speed  for alignment
            {
                CCR0 += 5000*4;   // Set slow speed
                P1OUT ^= 0x01;    //Toggle step clock
            }
            else
            {
                P1OUT = P1OUT | 0x08;     //OFF
            }
            counter = 0;
            if (!(P1IN & BIT6))     //Turn takeup on (rewind)
            {
                P1OUT = P1OUT | 0x02;
            }
            else
            {
                P1OUT = P1OUT & 0xFD;
            }
         }


}
